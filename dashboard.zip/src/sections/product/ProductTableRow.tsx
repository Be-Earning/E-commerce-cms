import { memo } from 'react'

const ProductTableRow = memo(() => {
  return <div>ProductTableRow</div>
})

export default ProductTableRow
