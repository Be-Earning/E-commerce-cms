import { memo } from 'react'

const PurchaseTableRow = memo(() => {
  return <div>PurchaseTableRow</div>
})

export default PurchaseTableRow
