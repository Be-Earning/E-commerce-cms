import { memo } from 'react'

const PurchaseDetailDialog = memo(() => {
  return <div>PurchaseDetailDialog</div>
})

export default PurchaseDetailDialog
