export { default as FooterEcom } from './FooterEcom'
