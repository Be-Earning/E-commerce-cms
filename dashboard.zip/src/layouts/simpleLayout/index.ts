export { default as SimpleLayout } from './SimpleLayout'
