export function pathRoot(root: string) {
  return `${root}`
}

export function path(root: string, subLink?: string) {
  return `${root}${subLink}`
}
