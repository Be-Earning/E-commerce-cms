export const SPLIT_KEY = {
  COMMENT: 'COMMENT'
}
