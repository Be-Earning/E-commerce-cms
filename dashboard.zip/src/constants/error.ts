export const ERR_MESSAGE = {
  TIMEOUT_RES: 'MAIN Time out no response!',
  INVALID_DEVIVE_KEY: 'Invalid last device key!',
  NOT_MATCH_HASH: 'Invalid last device key!'
}
