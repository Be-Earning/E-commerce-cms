import { memo } from 'react'

const Page403 = memo(() => {
  return <div>Page403</div>
})

export default Page403
