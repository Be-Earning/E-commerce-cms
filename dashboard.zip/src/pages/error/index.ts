export { default as Page404 } from './Page404'
