import { memo } from 'react'

const Page404 = memo(() => {
  return <div>Page404</div>
})

export default Page404
