export interface ISystemInfo {
  totalCfs: string
  totalShares: string
  totalVistors: string
}
