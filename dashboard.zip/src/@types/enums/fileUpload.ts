export const statusUploadCode = {
  FILE_TOO_LANRGE: 'File too large',
  TOO_MANY_FILES: 'Too many files'
}
