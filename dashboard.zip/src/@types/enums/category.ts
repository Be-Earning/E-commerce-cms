export enum EnumCategory {
  HEALTH = '1',
  COSMETIC = '2',
  FASHION = '3',
  FOOD = '4',
  DIGITAL = '5'
}

export const scCategory = {
  1: 'health',
  2: 'cosmetic',
  3: 'fashion',
  4: 'food',
  5: 'digital'
}
