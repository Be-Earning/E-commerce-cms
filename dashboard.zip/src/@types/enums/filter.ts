export enum TimeFilter {
  MONTHS_12 = '12months',
  DAYS_30 = '30days',
  DAYS_7 = '7days',
  HOURS_24 = '24hours'
}
