export enum EnumCommentType {
  REVIEW,
  PRESSCOMMENT
}
