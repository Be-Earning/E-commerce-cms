export enum Role {
  ADMIN,
  CUSTOMER,
  RETAILER,
  CONTROLLER
}
