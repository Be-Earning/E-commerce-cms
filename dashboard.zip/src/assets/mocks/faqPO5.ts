import { IFAQProduct } from '~/@types/models'

export const faqPO5: IFAQProduct[] = [
  {
    id: 1,
    answer: 'What is PO5 return policy?',
    question:
      'Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor.',
    isNew: false
  },
  {
    id: 2,
    answer: 'How to complain about the product?',
    question:
      'Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor.',
    isNew: false
  },
  {
    id: 3,
    answer: 'What is the buyer protection policy?',
    question:
      'Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor.',
    isNew: false
  },
  {
    id: 4,
    answer: 'What is the refund policy?',
    question:
      'Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor ea commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor commodo consequat aute irure dolor ex ea commodo consequat aute irure dolor.',
    isNew: false
  }
]
