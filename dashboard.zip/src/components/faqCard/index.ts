export { default as FaqCard } from './FaqCard'
