export { default as SliderPagination } from './SliderPagination'
