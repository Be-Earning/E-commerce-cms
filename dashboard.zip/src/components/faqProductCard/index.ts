export { default as FaqProductCard } from './FaqProductCard'
