export { default as Tabs } from './Tabs'
