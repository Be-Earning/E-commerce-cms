import { memo } from 'react'

const DecreaseIcon = memo(() => {
  return <div>DecreaseIcon</div>
})

export default DecreaseIcon
