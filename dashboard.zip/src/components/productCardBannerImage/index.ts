export { default as ProductCardBannerImage } from './ProductCardBannerImage'
