export { default as GlobalWarranty } from './GlobalWarranty'
